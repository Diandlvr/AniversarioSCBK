# Cómo agregar fotos reales

## 1. Coloca tus imágenes aquí
```
public/photos/
  hero.jpg          ← foto principal del hero
  primera-cita.jpg  ← primera cita
  primer-cafe.jpg   ← primer café
  te-quiero.jpg     ← primer te quiero
  booth-1.jpg       ← tira de fotos (x4)
  booth-2.jpg
  booth-3.jpg
  booth-4.jpg
  gallery-1.jpg     ← galería polaroids
  gallery-2.jpg
  gallery-3.jpg
  movie-1.jpg       ← pósters de películas (opcionales)
  movie-2.jpg
  movie-3.jpg
```

## 2. Activar next/image en los componentes

En **Hero.tsx**, reemplaza el bloque `<div className={s.placeholder}>` por:
```tsx
import Image from "next/image";

// dentro del componente:
<Image
  src={config.hero.photoSrc}
  alt={config.hero.photoAlt}
  fill
  priority
  style={{ objectFit: "cover", objectPosition: "center top" }}
/>
```

En **FirstMoments.tsx**, reemplaza `<PhotoPlaceholder />` por:
```tsx
import Image from "next/image";
<Image src={moment.photoSrc} alt={moment.photoAlt} fill style={{ objectFit: "cover" }} />
```

En **PhotoBooth.tsx**, reemplaza `<FramePlaceholder />` por:
```tsx
import Image from "next/image";
<Image src={photo.src} alt={photo.alt} fill style={{ objectFit: "cover" }} />
```

En **MoviesWatched.tsx**, añade dentro de `.poster`:
```tsx
import Image from "next/image";
<Image src={movie.posterSrc} alt={movie.title} fill style={{ objectFit: "cover" }} />
```

## 3. Mapbox (sección Important Places)
Crea una cuenta gratuita en mapbox.com, copia tu token público y pégalo en `.env.local`:
```
NEXT_PUBLIC_MAPBOX_TOKEN=pk.eyJ1IjoiXXXX...
```

## 4. Formatos recomendados
- Hero: mínimo 1400×900px, formato paisaje o cuadrado
- Fotos de momentos: cualquier aspecto, el componente las recorta
- Photo booth strip: formato cuadrado o retrato funciona mejor
- Polaroids: cualquier aspecto
