# Álbum de Aniversario

**Stack:** Next.js 15 · TypeScript · CSS Modules · Framer Motion · Vercel

## Primeros pasos

```bash
npm install
npm run dev
```

Abre [http://localhost:3000](http://localhost:3000)

## Personalizar el contenido

Todo el contenido editable está en un solo archivo:

```
src/data/content.ts
```

Edita nombres, fechas, mensajes, canciones, razones, etc.

## Agregar fotos

Coloca tus imágenes en `/public/photos/` y referencia sus nombres en `content.ts`.

## Variables de entorno

Copia `.env.local` y rellena los valores:

```bash
NEXT_PUBLIC_MAPBOX_TOKEN=   # Para los mapas
NEXT_PUBLIC_SITE_URL=       # URL de producción
RESEND_API_KEY=             # (Opcional) Email al publicar
```

## Deploy en Vercel

```bash
git init && git add . && git commit -m "init"
# Sube a GitHub, luego importa en vercel.com
```

## Fases de implementación

| Fase | Contenido |
|---|---|
| 1 | Sistema de diseño base ✅ |
| 2 | Hero + CalendarDate + FirstMoments |
| 3 | PhotoBooth + FavoriteMessages + Tickets |
| 4 | ImportantPlaces + OurSongs + MoviesWatched |
| 5 | ReasonsILoveYou + ThingsYouTaughtMe + LoveNote |
| 6 | NavDots, animaciones, optimización |
| 7 | API routes, deploy final |
