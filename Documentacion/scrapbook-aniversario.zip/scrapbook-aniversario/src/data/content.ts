// ============================================================
// SCRAPBOOK ANIVERSARIO — Contenido
// ← Editar aquí todo el contenido personalizado
// ============================================================

export const config = {
  // Nombres
  names: {
    yours: "Tu Nombre",
    hers: "Su Nombre",
  },

  // La fecha del aniversario (YYYY-MM-DD)
  anniversaryDate: "2024-06-15",

  // Texto del Hero
  hero: {
    tagline: "Un año de",
    title: "nosotros.",
    subtitle: "De todo lo que somos juntos.",
    // Coloca la imagen en public/photos/ y escribe el nombre aquí
    photoSrc: "/photos/hero.jpg",
    photoAlt: "Nosotros",
  },
};

// --- Sección: First Moments ---
export const firstMoments = [
  {
    id: "primera-cita",
    label: "Primera cita",
    date: "Jun 15, 2024",
    caption: "El café que se enfría mientras hablan sin parar.",
    photoSrc: "/photos/primera-cita.jpg",
    photoAlt: "Primera cita",
  },
  {
    id: "primer-cafe",
    label: "Primer café",
    date: "Jun 16, 2024",
    caption: "El momento en que todo empezó a tener sentido.",
    photoSrc: "/photos/primer-cafe.jpg",
    photoAlt: "Primer café",
  },
  {
    id: "primer-te-quiero",
    label: "Primer \"te quiero\"",
    date: "Jul 4, 2024",
    caption: "Tres palabras que lo cambiaron todo.",
    photoSrc: "/photos/te-quiero.jpg",
    photoAlt: "El momento",
  },
];

// --- Sección: Favorite Messages ---
export const favoriteMessages = [
  {
    id: "msg-1",
    conversation: [
      { sender: "her",  text: "Buenos días 🌅" },
      { sender: "you",  text: "Buenos días tú. ¿Dormiste bien?" },
      { sender: "her",  text: "Sí. Soñé algo bonito." },
      { sender: "you",  text: "¿Qué soñaste?" },
      { sender: "her",  text: "Contigo." },
    ],
  },
  {
    id: "msg-2",
    conversation: [
      { sender: "you",  text: "¿Qué estás haciendo?" },
      { sender: "her",  text: "Pensando en ti." },
      { sender: "you",  text: "Eso es lo mejor que me han dicho hoy." },
      { sender: "her",  text: "Espera a que te diga lo que pienso 😊" },
    ],
  },
];

// --- Sección: Photo Booth ---
export const photoBooth = {
  strip: [
    { src: "/photos/booth-1.jpg", alt: "Foto 1" },
    { src: "/photos/booth-2.jpg", alt: "Foto 2" },
    { src: "/photos/booth-3.jpg", alt: "Foto 3" },
    { src: "/photos/booth-4.jpg", alt: "Foto 4" },
  ],
  gallery: [
    { src: "/photos/gallery-1.jpg", alt: "Galería 1", caption: "Descripción 1" },
    { src: "/photos/gallery-2.jpg", alt: "Galería 2", caption: "Descripción 2" },
    { src: "/photos/gallery-3.jpg", alt: "Galería 3", caption: "Descripción 3" },
  ],
};

// --- Sección: Important Places ---
export const importantPlaces = [
  {
    id: "place-1",
    name: "El café de siempre",
    label: "first date",
    lat: 8.9936,
    lng: -79.5197,
    note: "Donde todo empezó.",
  },
  {
    id: "place-2",
    name: "Parque favorito",
    label: "first kiss",
    lat: 8.9942,
    lng: -79.5243,
    note: "El lugar más nuestro.",
  },
  {
    id: "place-3",
    name: "Restaurante especial",
    label: "first 'I love you'",
    lat: 8.9921,
    lng: -79.5134,
    note: "La noche perfecta.",
  },
];

// --- Sección: Tickets & Events ---
export const tickets = [
  {
    id: "ticket-1",
    event: "Nombre del Concierto",
    venue: "Nombre del Venue",
    city: "Ciudad",
    date: "15 JUN 2024",
    seat: "GA",
  },
  {
    id: "ticket-2",
    event: "Película Especial",
    venue: "Cine del Barrio",
    city: "Ciudad",
    date: "4 JUL 2024",
    seat: "Fila D · 12",
  },
];

// --- Sección: Our Songs ---
export const ourSongs = [
  {
    id: "song-1",
    title: "Nombre de la canción",
    artist: "Artista",
    note: "La que sonó aquella noche.",
    spotifyUrl: "", // Opcional
  },
  {
    id: "song-2",
    title: "Otra canción",
    artist: "Artista",
    note: "La que siempre cantamos juntos.",
    spotifyUrl: "",
  },
  {
    id: "song-3",
    title: "La favorita",
    artist: "Artista",
    note: "La nuestra.",
    spotifyUrl: "",
  },
];

// --- Sección: Movies Watched ---
export const moviesWatched = [
  {
    id: "movie-1",
    title: "Película 1",
    year: "2024",
    note: "La vimos en casa con palomitas.",
    posterSrc: "/photos/movie-1.jpg",
  },
  {
    id: "movie-2",
    title: "Película 2",
    year: "2023",
    note: "Lloramos juntos al final.",
    posterSrc: "/photos/movie-2.jpg",
  },
  {
    id: "movie-3",
    title: "Película 3",
    year: "2024",
    note: "La que quería que viera.",
    posterSrc: "/photos/movie-3.jpg",
  },
];

// --- Sección: Reasons I Love You ---
export const reasonsILoveYou = [
  "La forma en que ríes cuando algo te parece muy gracioso.",
  "Cómo me escuchas de verdad, no solo con los oídos.",
  "Tu curiosidad por todo lo que te rodea.",
  "Lo mucho que cuidas a las personas que amas.",
  "Esa canción que tararea sin darse cuenta.",
  "Lo honesta que eres, incluso cuando es difícil.",
  "Tu manera de ver el mundo con ojos propios.",
  "Cómo me haces sentir que todo tiene sentido.",
  "Lo mucho que me has enseñado sin proponértelo.",
  "Simplemente, ser tú.",
  "Todo lo que aún no he descubierto de ti.",
  "Que existas.",
];

// --- Sección: Things You've Taught Me ---
export const thingsYouTaughtMe = [
  "Que estar presente es la forma más alta de amor.",
  "Que hay belleza en las cosas pequeñas si sabes mirar.",
  "Que pedir ayuda no es debilidad.",
  "Que el silencio entre dos personas puede ser íntimo.",
  "Que un café a tiempo lo arregla casi todo.",
  "Que vale la pena decir lo que uno siente.",
];

// --- Sección: Love Note ---
export const loveNote = {
  greeting: "Para ti,",
  body: [
    "Un año no es poco. Es 365 días eligiendo al otro, eligiéndonos.",
    "Es la acumulación de buenos días y buenas noches, de cafés compartidos y películas vistas, de palabras dichas a tiempo y abrazos que llegan justo cuando se necesitan.",
    "Gracias por todo lo que eres, por todo lo que me has dado, por todo lo que somos juntos.",
    "Esto no es un final. Es apenas el comienzo de todo lo que viene.",
  ],
  closing: "Con todo mi amor,",
  signature: "Tu Nombre",
};
