import { tickets } from "@/data/content";
import s from "./Tickets.module.css";

function Barcode() {
  return (
    <div className={s.barcode}>
      {Array.from({ length: 14 }).map((_, i) => <span key={i} />)}
    </div>
  );
}

export default function Tickets() {
  return (
    <section className={s.section}>
      <div className={s.noiseBg} />
      <div className={s.inner}>
        <div className={s.header}>
          <span className={s.eyebrow}>07 · eventos</span>
          <h2 className={s.title}>Tickets & Events</h2>
        </div>
        <div className={s.ticketsWrap}>
          {tickets.map((t) => (
            <div key={t.id} className={s.ticket}>
              <div className={s.ticketMain}>
                <p className={s.ticketEvent}>{t.event}</p>
                <p className={s.ticketVenue}>{t.venue}</p>
                <p className={s.ticketCity}>{t.city}</p>
              </div>
              <div className={s.ticketStub}>
                <span className={s.ticketDate}>{t.date}</span>
                <Barcode />
                <span className={s.ticketSeat}>{t.seat}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
