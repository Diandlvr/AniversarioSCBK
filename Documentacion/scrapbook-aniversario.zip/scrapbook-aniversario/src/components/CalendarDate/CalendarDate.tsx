import { config } from "@/data/content";
import s from "./CalendarDate.module.css";

const DAY_NAMES = ["Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sá"];
const MONTH_NAMES = ["Enero","Febrero","Marzo","Abril","Mayo","Junio",
  "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

function buildCalendar(isoDate: string) {
  const date = new Date(isoDate + "T12:00:00");
  const year = date.getFullYear();
  const month = date.getMonth();
  const special = date.getDate();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  return { year, month, special, firstDay, daysInMonth };
}

export default function CalendarDate() {
  const { year, month, special, firstDay, daysInMonth } = buildCalendar(config.anniversaryDate);
  const blanks = Array(firstDay).fill(null);
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  return (
    <div className={s.section}>
      <div className={s.inner}>
        <p className={s.topNote}>El día que todo empezó a cambiar.</p>

        <div className={s.calendarCard}>
          <div className={s.calendarHeader}>
            <p className={s.monthLabel}>{MONTH_NAMES[month]}</p>
            <p className={s.yearLabel}>{year}</p>
          </div>

          <div className={s.grid}>
            {DAY_NAMES.map((d) => (
              <div key={d} className={s.dayName}>{d}</div>
            ))}
            {blanks.map((_, i) => (
              <div key={`b-${i}`} className={`${s.dayCell} ${s.empty}`}>·</div>
            ))}
            {days.map((d) => (
              <div key={d} className={`${s.dayCell} ${d === special ? s.special : ""}`}>
                {d === special && <span className={s.specialCircle} />}
                {d}
              </div>
            ))}
          </div>
        </div>

        <p className={s.bottomNote}>
          Este día quedó marcado para siempre.
        </p>
      </div>
    </div>
  );
}
