import { loveNote } from "@/data/content";
import s from "./LoveNote.module.css";

export default function LoveNote() {
  return (
    <section className={s.section}>
      <div className={s.paper}>
        <span className={s.eyebrow}>12 · carta final</span>
        <p className={s.greeting}>{loveNote.greeting}</p>
        <div className={s.body}>
          {loveNote.body.map((paragraph, i) => (
            <p key={i}>{paragraph}</p>
          ))}
        </div>
        <span className={s.closing}>{loveNote.closing}</span>
        <span className={s.signature}>{loveNote.signature}</span>
      </div>
    </section>
  );
}
