import { moviesWatched } from "@/data/content";
import s from "./MoviesWatched.module.css";

export default function MoviesWatched() {
  return (
    <section className={s.section}>
      <div className={s.inner}>
        <div className={s.header}>
          <span className={s.eyebrow}>09 · películas</span>
          <h2 className={s.title}>Movies We&apos;ve Watched</h2>
        </div>
        <div className={s.grid}>
          {moviesWatched.map((movie) => (
            <div key={movie.id} className={s.movieCard}>
              <div className={s.poster}>
                {/* Poster placeholder — reemplaza con <Image> cuando tengas los archivos */}
                <div className={s.posterPlaceholder}>
                  <p className={s.posterPlaceholderTitle}>{movie.title}</p>
                  <span className={s.posterPlaceholderYear}>{movie.year}</span>
                </div>
                <div className={s.overlay}>
                  <p className={s.overlayNote}>{movie.note}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
