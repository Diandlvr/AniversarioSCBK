"use client";
import { config } from "@/data/content";
import { formatDate } from "@/lib/utils";
import s from "./Hero.module.css";

export default function Hero() {
  const dateFormatted = formatDate(config.anniversaryDate).toUpperCase();

  return (
    <div className={s.hero}>
      {/* Zona de foto — reemplaza con <Image> cuando tengas la foto real */}
      <div className={s.photoWrapper}>
        <div className={s.placeholder}>
          <span className={s.placeholderText}>
            coloca tu foto aquí → public/photos/hero.jpg
          </span>
        </div>
      </div>

      {/* Gradiente overlay */}
      <div className={s.overlay} />

      {/* Texto */}
      <div className={s.content}>
        <span className={s.eyebrow}>
          {config.anniversaryDate.slice(0, 4)} · aniversario
        </span>
        <h1 className={s.title}>
          {config.hero.tagline}{" "}
          <em className={s.titleAccent}>{config.hero.title}</em>
        </h1>
        <p className={s.subtitle}>{config.hero.subtitle}</p>
        <span className={s.date}>{dateFormatted}</span>
      </div>

      {/* Scroll indicator */}
      <div className={s.scrollLine}>
        <span className={s.scrollLabel}>scroll</span>
        <div className={s.scrollBar} />
      </div>
    </div>
  );
}
