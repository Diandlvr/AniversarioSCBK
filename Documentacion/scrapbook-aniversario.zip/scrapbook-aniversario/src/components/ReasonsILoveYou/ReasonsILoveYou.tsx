"use client";
import { useState } from "react";
import { reasonsILoveYou } from "@/data/content";
import s from "./ReasonsILoveYou.module.css";

export default function ReasonsILoveYou() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggle = (i: number) =>
    setOpenIndex((prev) => (prev === i ? null : i));

  return (
    <section className={s.section}>
      <div className={s.inner}>
        <div className={s.header}>
          <span className={s.eyebrow}>10 · razones</span>
          <h2 className={s.title}>Reasons I Love You</h2>
        </div>
        <div className={s.grid}>
          {reasonsILoveYou.map((reason, i) => (
            <div
              key={i}
              className={`${s.envelope} ${openIndex === i ? s.open : ""}`}
              onClick={() => toggle(i)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === "Enter" && toggle(i)}
              aria-label={`Sobre ${i + 1}`}
            >
              <div className={s.envelopeInner}>
                <div className={s.front}>
                  <div className={s.envelopeFlap} />
                  <span className={s.envelopeLabel}>razón #{String(i + 1).padStart(2, "0")}</span>
                </div>
                <div className={s.back}>
                  <p className={s.reason}>{reason}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
