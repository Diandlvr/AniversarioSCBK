import { favoriteMessages } from "@/data/content";
import s from "./FavoriteMessages.module.css";

export default function FavoriteMessages() {
  return (
    <section className={s.section}>
      <div className={s.gridBg} />
      <div className={s.inner}>
        <div className={s.header}>
          <span className={s.eyebrow}>04 · mensajes</span>
          <h2 className={s.title}>Texts That Made Me Smile</h2>
        </div>
        <div className={s.columns}>
          {favoriteMessages.map((conv) => (
            <div key={conv.id} className={s.conversation}>
              {conv.conversation.map((msg, i) => (
                <div key={i} className={`${s.bubble} ${s[msg.sender]}`}>
                  {msg.text}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
