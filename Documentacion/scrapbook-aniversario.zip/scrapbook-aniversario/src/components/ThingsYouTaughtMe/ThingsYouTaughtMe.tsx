import { thingsYouTaughtMe } from "@/data/content";
import s from "./ThingsYouTaughtMe.module.css";

export default function ThingsYouTaughtMe() {
  return (
    <section className={s.section}>
      <div className={s.lineBg} />
      <div className={s.inner}>
        <div className={s.header}>
          <span className={s.eyebrow}>11 · lecciones</span>
          <h2 className={s.title}>Things You've Taught Me</h2>
        </div>
        <div className={s.list}>
          {thingsYouTaughtMe.map((lesson, i) => (
            <div key={i} className={s.item}>
              <span className={s.num}>{String(i + 1).padStart(2, "0")}</span>
              <p className={s.text}>{lesson}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
