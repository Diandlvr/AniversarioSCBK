"use client";
import { useState, useEffect } from "react";
import s from "./NavDots.module.css";

const SECTIONS = [
  { id: "hero", label: "Inicio" },
  { id: "calendar", label: "Calendario" },
  { id: "first-moments", label: "Primeros momentos" },
  { id: "messages", label: "Mensajes" },
  { id: "photo-booth", label: "Fotos" },
  { id: "places", label: "Lugares" },
  { id: "tickets", label: "Tickets" },
  { id: "songs", label: "Canciones" },
  { id: "movies", label: "Películas" },
  { id: "reasons", label: "Razones" },
  { id: "lessons", label: "Lecciones" },
  { id: "love-note", label: "Carta" },
];

export default function NavDots() {
  const [active, setActive] = useState("hero");

  useEffect(() => {
    const observers: IntersectionObserver[] = [];

    SECTIONS.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (!el) return;
      const obs = new IntersectionObserver(
        ([entry]) => { if (entry.isIntersecting) setActive(id); },
        { threshold: 0.4 }
      );
      obs.observe(el);
      observers.push(obs);
    });

    return () => observers.forEach((o) => o.disconnect());
  }, []);

  return (
    <nav className={s.nav} aria-label="Secciones">
      {SECTIONS.map(({ id, label }) => (
        <button
          key={id}
          className={`${s.dot} ${active === id ? s.active : ""}`}
          onClick={() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })}
          title={label}
          aria-label={label}
        />
      ))}
    </nav>
  );
}
