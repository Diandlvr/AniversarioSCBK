import { photoBooth } from "@/data/content";
import s from "./PhotoBooth.module.css";

function FramePlaceholder({ num }: { num: number }) {
  return (
    <div className={s.stripPlaceholder}>foto {num}</div>
  );
}

export default function PhotoBooth() {
  return (
    <section className={s.section}>
      <div className={s.inner}>
        <div>
          <div className={s.header}>
            <span className={s.eyebrow}>05 · galería</span>
            <h2 className={s.title}>Photo Booth</h2>
          </div>
          <div className={s.strip}>
            {photoBooth.strip.map((_, i) => (
              <div key={i} className={s.stripFrame}>
                <FramePlaceholder num={i + 1} />
              </div>
            ))}
          </div>
        </div>
        <div className={s.right}>
          <div className={s.gallery}>
            {photoBooth.gallery.map((photo, i) => (
              <div key={i} className={s.polaroid}>
                <div className={s.polaroidPhoto}>
                  <FramePlaceholder num={i + 1} />
                </div>
                <p className={s.polaroidCaption}>{photo.caption}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
