import { importantPlaces } from "@/data/content";
import s from "./ImportantPlaces.module.css";

const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_MAPBOX_TOKEN;

function getMapUrl(lat: number, lng: number) {
  if (!MAPBOX_TOKEN) return null;
  return `https://api.mapbox.com/styles/v1/mapbox/light-v11/static/pin-s+C4877A(${lng},${lat})/${lng},${lat},14/280x280@2x?access_token=${MAPBOX_TOKEN}`;
}

export default function ImportantPlaces() {
  return (
    <section className={s.section}>
      <div className={s.inner}>
        <div className={s.header}>
          <span className={s.eyebrow}>06 · lugares</span>
          <h2 className={s.title}>Important Places</h2>
        </div>
        <div className={s.grid}>
          {importantPlaces.map((place) => {
            const mapUrl = getMapUrl(place.lat, place.lng);
            return (
              <div key={place.id} className={s.placeCard}>
                <div className={s.mapFrame}>
                  {mapUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={mapUrl}
                      alt={place.name}
                      className={s.mapImg}
                      style={{ width: "100%", height: "100%", objectFit: "cover" }}
                    />
                  ) : (
                    <div className={s.mapPlaceholder}>
                      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
                        <path d="M12 21s-8-6.5-8-12a8 8 0 0116 0c0 5.5-8 12-8 12z"/>
                        <circle cx="12" cy="9" r="2"/>
                      </svg>
                      <span className={s.coords}>
                        {place.lat.toFixed(4)}, {place.lng.toFixed(4)}
                      </span>
                    </div>
                  )}
                </div>
                <span className={s.placeLabel}>{place.label}</span>
                <p className={s.placeName}>{place.name}</p>
                <p className={s.placeNote}>{place.note}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
