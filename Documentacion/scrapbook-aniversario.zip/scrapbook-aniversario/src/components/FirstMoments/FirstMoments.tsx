import { firstMoments } from "@/data/content";
import s from "./FirstMoments.module.css";

function PhotoPlaceholder({ label }: { label: string }) {
  return (
    <div className={s.photoPlaceholder}>
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
        <rect x="3" y="3" width="18" height="18" rx="1"/>
        <circle cx="8.5" cy="8.5" r="1.5"/>
        <polyline points="21 15 16 10 5 21"/>
      </svg>
      <span className={s.photoPlaceholderText}>{label}</span>
    </div>
  );
}

export default function FirstMoments() {
  return (
    <section className={s.section}>
      <div className={s.inner}>
        <div className={s.header}>
          <span className={s.eyebrow}>03 · primeras veces</span>
          <h2 className={s.title}>First Moments</h2>
        </div>
        <div className={s.grid}>
          {firstMoments.map((moment) => (
            <div key={moment.id} className={s.card}>
              <div className={s.photoBox}>
                <PhotoPlaceholder label={moment.photoAlt} />
              </div>
              <div className={s.cardBody}>
                <span className={s.cardLabel}>{moment.label}</span>
                <span className={s.cardDate}>{moment.date}</span>
                <p className={s.cardCaption}>{moment.caption}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
