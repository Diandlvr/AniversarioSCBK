import { ourSongs } from "@/data/content";
import s from "./OurSongs.module.css";

export default function OurSongs() {
  return (
    <section className={s.section}>
      <div className={s.inner}>
        <div className={s.header}>
          <span className={s.eyebrow}>08 · canciones</span>
          <h2 className={s.title}>Music That Reminds Me of You</h2>
        </div>
        <div className={s.grid}>
          {ourSongs.map((song) => (
            <div key={song.id} className={s.card}>
              <span className={s.artist}>{song.artist}</span>
              <p className={s.songTitle}>{song.title}</p>
              <p className={s.note}>{song.note}</p>
              {song.spotifyUrl && (
                <a href={song.spotifyUrl} target="_blank" rel="noopener noreferrer" className={s.spotifyLink}>
                  escuchar →
                </a>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
