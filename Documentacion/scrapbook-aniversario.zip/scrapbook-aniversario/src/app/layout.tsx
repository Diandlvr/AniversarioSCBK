import type { Metadata } from "next";
import { Playfair_Display, EB_Garamond, Cormorant, JetBrains_Mono } from "next/font/google";
import "./globals.css";

// --- Fuentes ---
const playfair = Playfair_Display({
  subsets: ["latin"],
  weight: ["400", "600", "700"],
  style: ["normal", "italic"],
  variable: "--font-playfair",
  display: "swap",
});

const garamond = EB_Garamond({
  subsets: ["latin"],
  weight: ["400", "500"],
  style: ["normal", "italic"],
  variable: "--font-garamond",
  display: "swap",
});

const cormorant = Cormorant({
  subsets: ["latin"],
  weight: ["300", "400"],
  style: ["normal", "italic"],
  variable: "--font-cormorant",
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["300", "400"],
  variable: "--font-jetbrains",
  display: "swap",
});

// --- Metadata --- (editar con los nombres reales)
export const metadata: Metadata = {
  title: "Un Año Contigo",
  description: "Un álbum de aniversario.",
  openGraph: {
    title: "Un Año Contigo",
    description: "Un álbum de aniversario.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body
        className={`${playfair.variable} ${garamond.variable} ${cormorant.variable} ${jetbrains.variable}`}
      >
        {children}
      </body>
    </html>
  );
}
