// ============================================================
// Utilidades globales
// ============================================================

/**
 * Combina clases CSS condicionalmente.
 * Reemplaza clsx sin dependencia extra.
 */
export function cn(...classes: (string | undefined | null | false)[]): string {
  return classes.filter(Boolean).join(" ");
}

/**
 * Formatea una fecha ISO a texto legible en español.
 * Ejemplo: "2024-06-15" → "15 de junio de 2024"
 */
export function formatDate(
  isoDate: string,
  options?: Intl.DateTimeFormatOptions
): string {
  const date = new Date(isoDate + "T12:00:00");
  return date.toLocaleDateString("es-ES", {
    day: "numeric",
    month: "long",
    year: "numeric",
    ...options,
  });
}

/**
 * Calcula días transcurridos entre una fecha y hoy.
 */
export function daysSince(isoDate: string): number {
  const start = new Date(isoDate);
  const now = new Date();
  const diff = now.getTime() - start.getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}

/**
 * Genera un número pseudoaleatorio estable a partir de un string.
 * Útil para rotar tickets o elementos decorativos de forma determinista.
 */
export function seededRandom(seed: string): number {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = ((hash << 5) - hash + seed.charCodeAt(i)) | 0;
  }
  return Math.abs(hash) / 2147483647;
}
